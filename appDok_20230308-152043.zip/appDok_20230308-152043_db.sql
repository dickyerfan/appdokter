#
# TABLE STRUCTURE FOR: data_pasien
#

DROP TABLE IF EXISTS `data_pasien`;

CREATE TABLE `data_pasien` (
  `id_pasien` int(11) NOT NULL AUTO_INCREMENT,
  `nama_pasien` varchar(255) NOT NULL,
  `alamat_pasien` varchar(255) NOT NULL,
  `telepon_pasien` varchar(13) NOT NULL,
  `jenkel_pasien` varchar(10) NOT NULL,
  `no_ktp` varchar(16) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `bpjs` varchar(13) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1,
  `keterangan` varchar(255) NOT NULL,
  PRIMARY KEY (`id_pasien`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;

INSERT INTO `data_pasien` (`id_pasien`, `nama_pasien`, `alamat_pasien`, `telepon_pasien`, `jenkel_pasien`, `no_ktp`, `tgl_lahir`, `bpjs`, `status`, `keterangan`) VALUES (1, 'Dea Afrizal', 'Perumahan Tamansari Indah RT11/RW 02 Bondowoso ', '081234567895', 'Laki-laki', '3511171703750004', '1975-03-17', '0000193516625', 1, '');
INSERT INTO `data_pasien` (`id_pasien`, `nama_pasien`, `alamat_pasien`, `telepon_pasien`, `jenkel_pasien`, `no_ktp`, `tgl_lahir`, `bpjs`, `status`, `keterangan`) VALUES (2, 'Sandhika Galih', 'Kademangan, Bondowoso', '082331796582', 'Laki-laki', '3511171511730004', '1973-11-15', '0000193516600', 1, '');
INSERT INTO `data_pasien` (`id_pasien`, `nama_pasien`, `alamat_pasien`, `telepon_pasien`, `jenkel_pasien`, `no_ktp`, `tgl_lahir`, `bpjs`, `status`, `keterangan`) VALUES (3, 'Elok Perdana', 'Jln. RE. Martadinata No 50 Bondowoso', '089776589312', 'Perempuan', '3511116007710005', '1971-07-20', '0000193516715', 1, '');
INSERT INTO `data_pasien` (`id_pasien`, `nama_pasien`, `alamat_pasien`, `telepon_pasien`, `jenkel_pasien`, `no_ktp`, `tgl_lahir`, `bpjs`, `status`, `keterangan`) VALUES (5, 'Andre Pratama', 'Jln. Khairil Anwar 10 Badean Bondowoso', '081332456965', 'Laki-laki', '3511122401730001', '1973-01-24', '', 1, '');
INSERT INTO `data_pasien` (`id_pasien`, `nama_pasien`, `alamat_pasien`, `telepon_pasien`, `jenkel_pasien`, `no_ktp`, `tgl_lahir`, `bpjs`, `status`, `keterangan`) VALUES (6, 'Eko Kurniawan Khanedy', 'Jln. Raya Situbondo 166 Tenggarang', '082331251471', 'Laki-laki', '3511080407680001', '1968-07-04', '', 1, '');
INSERT INTO `data_pasien` (`id_pasien`, `nama_pasien`, `alamat_pasien`, `telepon_pasien`, `jenkel_pasien`, `no_ktp`, `tgl_lahir`, `bpjs`, `status`, `keterangan`) VALUES (7, 'Novinaldi', 'Jln. RE. Martadinata Gang Patih No 14 Bondowoso', '082331796582', 'Laki-laki', '3511103012850001', '1985-12-30', '', 1, '');
INSERT INTO `data_pasien` (`id_pasien`, `nama_pasien`, `alamat_pasien`, `telepon_pasien`, `jenkel_pasien`, `no_ktp`, `tgl_lahir`, `bpjs`, `status`, `keterangan`) VALUES (8, 'Pelita Nur Afni', 'Jln. Situbondo RT12/01 Tenggarang', '08123465819', 'Perempuan', '3511110611960003', '1996-11-06', '', 1, '');
INSERT INTO `data_pasien` (`id_pasien`, `nama_pasien`, `alamat_pasien`, `telepon_pasien`, `jenkel_pasien`, `no_ktp`, `tgl_lahir`, `bpjs`, `status`, `keterangan`) VALUES (9, 'Welda Rahmaningsih', 'Perum Sukowiryo Indah no 67 Sukowiryo Bondowoso', '082331712569', 'Perempuan', '3511112501920002', '1992-01-25', '', 1, '');
INSERT INTO `data_pasien` (`id_pasien`, `nama_pasien`, `alamat_pasien`, `telepon_pasien`, `jenkel_pasien`, `no_ktp`, `tgl_lahir`, `bpjs`, `status`, `keterangan`) VALUES (10, 'Cinta Tak Bertuan', 'Perum Garden Village no 34 Badean Bondowoso', '082345965815', 'Perempuan', '3511171706990002', '1999-06-17', '', 1, '');
INSERT INTO `data_pasien` (`id_pasien`, `nama_pasien`, `alamat_pasien`, `telepon_pasien`, `jenkel_pasien`, `no_ktp`, `tgl_lahir`, `bpjs`, `status`, `keterangan`) VALUES (11, 'Kunto Negoro Aji', 'Jln. Wahid Hasyim Gang III Blindungan Bondowoso', '08171236598', 'Laki-laki', '3511110607000005', '2000-07-06', '', 1, '');
INSERT INTO `data_pasien` (`id_pasien`, `nama_pasien`, `alamat_pasien`, `telepon_pasien`, `jenkel_pasien`, `no_ktp`, `tgl_lahir`, `bpjs`, `status`, `keterangan`) VALUES (12, 'Intan Permata Hati', 'Jln. Wahidin Sudirohusodo No 65 Bondowoso', '085331256932', 'Perempuan', '3511103010900001', '1990-10-30', '0000193516615', 1, '');
INSERT INTO `data_pasien` (`id_pasien`, `nama_pasien`, `alamat_pasien`, `telepon_pasien`, `jenkel_pasien`, `no_ktp`, `tgl_lahir`, `bpjs`, `status`, `keterangan`) VALUES (13, 'Rio Setiawan Jaya', 'Jln. Zainul Arifin Gang Mesjid no 99 Bondowoso', '081226598254', 'Laki-laki', '3511110108790005', '1979-08-01', '0000193516666', 1, '');
INSERT INTO `data_pasien` (`id_pasien`, `nama_pasien`, `alamat_pasien`, `telepon_pasien`, `jenkel_pasien`, `no_ktp`, `tgl_lahir`, `bpjs`, `status`, `keterangan`) VALUES (14, 'Rianti Dwi Jayanti', 'Jln. WR. Supratman No 35 RT11/01 Bondowoso', '082331796582', 'Perempuan', '3511171905760004', '1976-05-19', '', 1, '');


#
# TABLE STRUCTURE FOR: jadwal_periksa
#

DROP TABLE IF EXISTS `jadwal_periksa`;

CREATE TABLE `jadwal_periksa` (
  `id_jadwal` int(11) NOT NULL AUTO_INCREMENT,
  `id_pasien` int(11) NOT NULL,
  `id_jam` int(11) NOT NULL,
  `id_tanggal` int(11) NOT NULL,
  `status_pasien` int(1) NOT NULL DEFAULT 0,
  `ket_tanggal` varchar(255) NOT NULL,
  PRIMARY KEY (`id_jadwal`),
  KEY `id_pasien` (`id_pasien`),
  KEY `id_jam` (`id_jam`),
  KEY `id_tanggal` (`id_tanggal`),
  CONSTRAINT `jadwal_periksa_ibfk_1` FOREIGN KEY (`id_pasien`) REFERENCES `data_pasien` (`id_pasien`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `jadwal_periksa_ibfk_2` FOREIGN KEY (`id_jam`) REFERENCES `jam_periksa` (`id_jam`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `jadwal_periksa_ibfk_3` FOREIGN KEY (`id_tanggal`) REFERENCES `tanggal_pasien` (`id_tanggal`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4;

INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (1, 1, 1, 1, 1, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (2, 2, 1, 2, 1, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (3, 3, 2, 2, 1, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (4, 1, 3, 2, 1, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (5, 1, 1, 3, 1, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (6, 2, 1, 4, 1, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (7, 3, 2, 4, 1, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (8, 1, 3, 4, 1, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (9, 2, 4, 4, 1, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (10, 2, 1, 5, 1, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (11, 1, 5, 6, 1, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (12, 6, 1, 15, 1, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (13, 6, 1, 17, 3, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (14, 3, 1, 18, 3, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (15, 6, 6, 18, 3, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (16, 2, 2, 18, 3, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (17, 5, 3, 18, 3, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (18, 1, 5, 18, 3, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (19, 1, 1, 19, 3, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (20, 2, 2, 19, 2, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (21, 1, 1, 20, 3, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (22, 3, 2, 20, 3, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (23, 5, 3, 20, 3, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (24, 2, 5, 20, 2, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (25, 2, 1, 21, 2, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (26, 5, 2, 21, 1, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (27, 1, 1, 23, 3, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (28, 2, 2, 23, 3, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (29, 3, 3, 23, 3, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (30, 6, 1, 24, 3, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (31, 5, 2, 24, 3, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (32, 1, 1, 25, 0, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (33, 10, 2, 25, 0, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (34, 11, 13, 25, 0, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (35, 6, 12, 25, 0, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (36, 7, 11, 25, 0, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (37, 2, 5, 25, 0, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (38, 12, 14, 25, 0, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (39, 9, 10, 25, 0, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (40, 1, 13, 26, 0, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (41, 2, 1, 26, 0, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (42, 5, 3, 25, 0, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (43, 13, 6, 25, 0, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (44, 13, 13, 29, 3, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (45, 14, 1, 29, 3, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (46, 5, 2, 29, 3, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (47, 3, 14, 29, 2, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (48, 1, 13, 30, 3, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (49, 7, 1, 30, 3, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (52, 12, 2, 30, 3, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (53, 11, 13, 31, 3, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (54, 10, 1, 31, 3, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (55, 13, 2, 31, 3, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (56, 5, 14, 31, 3, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (57, 1, 3, 31, 3, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (58, 3, 5, 31, 3, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (59, 14, 6, 31, 3, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (60, 2, 12, 31, 3, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (61, 6, 10, 31, 3, '');
INSERT INTO `jadwal_periksa` (`id_jadwal`, `id_pasien`, `id_jam`, `id_tanggal`, `status_pasien`, `ket_tanggal`) VALUES (62, 9, 11, 31, 3, '');


#
# TABLE STRUCTURE FOR: jam_periksa
#

DROP TABLE IF EXISTS `jam_periksa`;

CREATE TABLE `jam_periksa` (
  `id_jam` int(11) NOT NULL AUTO_INCREMENT,
  `jam` varchar(50) NOT NULL,
  `status_jam` int(1) NOT NULL DEFAULT 1,
  `ket_jam` varchar(50) NOT NULL,
  PRIMARY KEY (`id_jam`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;

INSERT INTO `jam_periksa` (`id_jam`, `jam`, `status_jam`, `ket_jam`) VALUES (1, '16.00 - 16.30', 1, 'Praktek');
INSERT INTO `jam_periksa` (`id_jam`, `jam`, `status_jam`, `ket_jam`) VALUES (2, '16.30 - 17.00', 1, 'Praktek');
INSERT INTO `jam_periksa` (`id_jam`, `jam`, `status_jam`, `ket_jam`) VALUES (3, '17.30 - 18.00', 1, 'Praktek');
INSERT INTO `jam_periksa` (`id_jam`, `jam`, `status_jam`, `ket_jam`) VALUES (4, '18.00 - 18.30', 1, 'Sholat');
INSERT INTO `jam_periksa` (`id_jam`, `jam`, `status_jam`, `ket_jam`) VALUES (5, '18.30 - 19.00', 1, 'Praktek');
INSERT INTO `jam_periksa` (`id_jam`, `jam`, `status_jam`, `ket_jam`) VALUES (6, '19.00 - 19.30', 1, 'Praktek');
INSERT INTO `jam_periksa` (`id_jam`, `jam`, `status_jam`, `ket_jam`) VALUES (10, '19.30 - 20.00', 1, 'Praktek');
INSERT INTO `jam_periksa` (`id_jam`, `jam`, `status_jam`, `ket_jam`) VALUES (11, '20.00 - 20.30', 1, 'Praktek');
INSERT INTO `jam_periksa` (`id_jam`, `jam`, `status_jam`, `ket_jam`) VALUES (12, '20.30 - 21.00', 1, 'Praktek');
INSERT INTO `jam_periksa` (`id_jam`, `jam`, `status_jam`, `ket_jam`) VALUES (13, '15.30 - 16.00', 1, 'Praktek');
INSERT INTO `jam_periksa` (`id_jam`, `jam`, `status_jam`, `ket_jam`) VALUES (14, '17.00 - 17.30', 1, 'Praktek');


#
# TABLE STRUCTURE FOR: kunjungan_pasien
#

DROP TABLE IF EXISTS `kunjungan_pasien`;

CREATE TABLE `kunjungan_pasien` (
  `id_kunjungan` int(11) NOT NULL AUTO_INCREMENT,
  `id_jadwal` int(11) NOT NULL,
  `id_tindakan` int(11) DEFAULT NULL,
  `id_tindakan2` int(11) NOT NULL,
  `keluhan` varchar(255) DEFAULT NULL,
  `jumlah` int(2) DEFAULT NULL,
  `jumlah2` int(2) NOT NULL,
  `tagihan` int(11) DEFAULT NULL,
  `ket_kunjungan` varchar(255) NOT NULL,
  PRIMARY KEY (`id_kunjungan`),
  KEY `id_pasien` (`id_jadwal`),
  KEY `id_proses` (`id_tindakan`),
  KEY `id_tindakan2` (`id_tindakan2`),
  CONSTRAINT `kunjungan_pasien_ibfk_1` FOREIGN KEY (`id_jadwal`) REFERENCES `jadwal_periksa` (`id_jadwal`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `kunjungan_pasien_ibfk_2` FOREIGN KEY (`id_tindakan`) REFERENCES `tindakan` (`id_tindakan`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4;

INSERT INTO `kunjungan_pasien` (`id_kunjungan`, `id_jadwal`, `id_tindakan`, `id_tindakan2`, `keluhan`, `jumlah`, `jumlah2`, `tagihan`, `ket_kunjungan`) VALUES (1, 14, 1, 7, 'Gigi Berlubang', 1, 1, 100000, '');
INSERT INTO `kunjungan_pasien` (`id_kunjungan`, `id_jadwal`, `id_tindakan`, `id_tindakan2`, `keluhan`, `jumlah`, `jumlah2`, `tagihan`, `ket_kunjungan`) VALUES (3, 16, 2, 7, 'Gigi Keropos', 1, 1, 100000, '');
INSERT INTO `kunjungan_pasien` (`id_kunjungan`, `id_jadwal`, `id_tindakan`, `id_tindakan2`, `keluhan`, `jumlah`, `jumlah2`, `tagihan`, `ket_kunjungan`) VALUES (4, 17, 4, 6, 'Gigi Ompong', 2, 2, 400000, '');
INSERT INTO `kunjungan_pasien` (`id_kunjungan`, `id_jadwal`, `id_tindakan`, `id_tindakan2`, `keluhan`, `jumlah`, `jumlah2`, `tagihan`, `ket_kunjungan`) VALUES (5, 18, 4, 6, 'Gigi Ompong', 3, 3, 600000, '');
INSERT INTO `kunjungan_pasien` (`id_kunjungan`, `id_jadwal`, `id_tindakan`, `id_tindakan2`, `keluhan`, `jumlah`, `jumlah2`, `tagihan`, `ket_kunjungan`) VALUES (6, 15, 1, 7, 'Gigi Berlubang', 3, 2, 300000, '');
INSERT INTO `kunjungan_pasien` (`id_kunjungan`, `id_jadwal`, `id_tindakan`, `id_tindakan2`, `keluhan`, `jumlah`, `jumlah2`, `tagihan`, `ket_kunjungan`) VALUES (7, 19, 1, 7, 'Gigi Berlubang', 2, 2, 200000, '');
INSERT INTO `kunjungan_pasien` (`id_kunjungan`, `id_jadwal`, `id_tindakan`, `id_tindakan2`, `keluhan`, `jumlah`, `jumlah2`, `tagihan`, `ket_kunjungan`) VALUES (8, 20, NULL, 0, '', NULL, 0, NULL, '');
INSERT INTO `kunjungan_pasien` (`id_kunjungan`, `id_jadwal`, `id_tindakan`, `id_tindakan2`, `keluhan`, `jumlah`, `jumlah2`, `tagihan`, `ket_kunjungan`) VALUES (9, 21, 7, 10, 'Gigi  geraham belakang sakit dan linu', 2, 2, 400000, '');
INSERT INTO `kunjungan_pasien` (`id_kunjungan`, `id_jadwal`, `id_tindakan`, `id_tindakan2`, `keluhan`, `jumlah`, `jumlah2`, `tagihan`, `ket_kunjungan`) VALUES (10, 22, 1, 7, 'Gigi Sakit', 1, 2, 250000, '');
INSERT INTO `kunjungan_pasien` (`id_kunjungan`, `id_jadwal`, `id_tindakan`, `id_tindakan2`, `keluhan`, `jumlah`, `jumlah2`, `tagihan`, `ket_kunjungan`) VALUES (11, 23, 7, 10, 'Gigi Berlubang dan sakit', 2, 2, 500000, '');
INSERT INTO `kunjungan_pasien` (`id_kunjungan`, `id_jadwal`, `id_tindakan`, `id_tindakan2`, `keluhan`, `jumlah`, `jumlah2`, `tagihan`, `ket_kunjungan`) VALUES (12, 24, NULL, 0, '', NULL, 0, NULL, '');
INSERT INTO `kunjungan_pasien` (`id_kunjungan`, `id_jadwal`, `id_tindakan`, `id_tindakan2`, `keluhan`, `jumlah`, `jumlah2`, `tagihan`, `ket_kunjungan`) VALUES (13, 25, NULL, 0, '', NULL, 0, NULL, '');
INSERT INTO `kunjungan_pasien` (`id_kunjungan`, `id_jadwal`, `id_tindakan`, `id_tindakan2`, `keluhan`, `jumlah`, `jumlah2`, `tagihan`, `ket_kunjungan`) VALUES (14, 27, 1, 2, 'Gigi hitam dan berlubang', 2, 2, 200000, '');
INSERT INTO `kunjungan_pasien` (`id_kunjungan`, `id_jadwal`, `id_tindakan`, `id_tindakan2`, `keluhan`, `jumlah`, `jumlah2`, `tagihan`, `ket_kunjungan`) VALUES (15, 28, 5, 6, 'Pemeriksaan Gigi Rutin', 6, 1, 1100000, '');
INSERT INTO `kunjungan_pasien` (`id_kunjungan`, `id_jadwal`, `id_tindakan`, `id_tindakan2`, `keluhan`, `jumlah`, `jumlah2`, `tagihan`, `ket_kunjungan`) VALUES (16, 29, 5, 6, 'Pemeriksaan Gigi Rutin', 3, 2, 450000, '');
INSERT INTO `kunjungan_pasien` (`id_kunjungan`, `id_jadwal`, `id_tindakan`, `id_tindakan2`, `keluhan`, `jumlah`, `jumlah2`, `tagihan`, `ket_kunjungan`) VALUES (17, 30, 10, 6, 'Pemeriksaan Gigi Rutin', 1, 1, 100000, '');
INSERT INTO `kunjungan_pasien` (`id_kunjungan`, `id_jadwal`, `id_tindakan`, `id_tindakan2`, `keluhan`, `jumlah`, `jumlah2`, `tagihan`, `ket_kunjungan`) VALUES (18, 31, 13, 6, 'Pemeriksaan Gigi Rutin', 2, 0, 200000, '');
INSERT INTO `kunjungan_pasien` (`id_kunjungan`, `id_jadwal`, `id_tindakan`, `id_tindakan2`, `keluhan`, `jumlah`, `jumlah2`, `tagihan`, `ket_kunjungan`) VALUES (19, 44, 5, 6, 'Pemeriksaan Gigi Rutin', 2, 3, 1000000, '');
INSERT INTO `kunjungan_pasien` (`id_kunjungan`, `id_jadwal`, `id_tindakan`, `id_tindakan2`, `keluhan`, `jumlah`, `jumlah2`, `tagihan`, `ket_kunjungan`) VALUES (20, 45, 5, 6, 'Pemeriksaan Gigi Rutin', 1, 1, 400000, '');
INSERT INTO `kunjungan_pasien` (`id_kunjungan`, `id_jadwal`, `id_tindakan`, `id_tindakan2`, `keluhan`, `jumlah`, `jumlah2`, `tagihan`, `ket_kunjungan`) VALUES (21, 46, 2, 0, 'Gigi linu dan sakit', 2, 0, 200000, '');
INSERT INTO `kunjungan_pasien` (`id_kunjungan`, `id_jadwal`, `id_tindakan`, `id_tindakan2`, `keluhan`, `jumlah`, `jumlah2`, `tagihan`, `ket_kunjungan`) VALUES (26, 48, 1, 7, 'Gigi hitam dan berlubang', 1, 1, 250000, '');
INSERT INTO `kunjungan_pasien` (`id_kunjungan`, `id_jadwal`, `id_tindakan`, `id_tindakan2`, `keluhan`, `jumlah`, `jumlah2`, `tagihan`, `ket_kunjungan`) VALUES (27, 49, 5, 6, 'Pemeriksaan gigi rutin', 1, 1, 750000, '');
INSERT INTO `kunjungan_pasien` (`id_kunjungan`, `id_jadwal`, `id_tindakan`, `id_tindakan2`, `keluhan`, `jumlah`, `jumlah2`, `tagihan`, `ket_kunjungan`) VALUES (28, 52, 7, 5, 'Gigi Sakit dan linu', 2, 1, 750000, '');
INSERT INTO `kunjungan_pasien` (`id_kunjungan`, `id_jadwal`, `id_tindakan`, `id_tindakan2`, `keluhan`, `jumlah`, `jumlah2`, `tagihan`, `ket_kunjungan`) VALUES (29, 53, 1, 0, 'Gigi berlubang', 2, 0, 200000, '');
INSERT INTO `kunjungan_pasien` (`id_kunjungan`, `id_jadwal`, `id_tindakan`, `id_tindakan2`, `keluhan`, `jumlah`, `jumlah2`, `tagihan`, `ket_kunjungan`) VALUES (30, 55, 2, 1, 'Gigi tinggal separuh dan ada yang berlubang', 1, 2, 300000, '');
INSERT INTO `kunjungan_pasien` (`id_kunjungan`, `id_jadwal`, `id_tindakan`, `id_tindakan2`, `keluhan`, `jumlah`, `jumlah2`, `tagihan`, `ket_kunjungan`) VALUES (31, 56, 5, 7, 'Pemeriksaan gigi rutin', 1, 1, 600000, '');
INSERT INTO `kunjungan_pasien` (`id_kunjungan`, `id_jadwal`, `id_tindakan`, `id_tindakan2`, `keluhan`, `jumlah`, `jumlah2`, `tagihan`, `ket_kunjungan`) VALUES (32, 54, 2, 0, 'Gigi berlubang', 1, 0, 100000, '');
INSERT INTO `kunjungan_pasien` (`id_kunjungan`, `id_jadwal`, `id_tindakan`, `id_tindakan2`, `keluhan`, `jumlah`, `jumlah2`, `tagihan`, `ket_kunjungan`) VALUES (33, 57, 10, 6, 'Pemeriksaan gigi rutin', 1, 1, 650000, '');
INSERT INTO `kunjungan_pasien` (`id_kunjungan`, `id_jadwal`, `id_tindakan`, `id_tindakan2`, `keluhan`, `jumlah`, `jumlah2`, `tagihan`, `ket_kunjungan`) VALUES (34, 58, 1, 0, 'Gigi Berlubang', 2, 0, 200000, '');
INSERT INTO `kunjungan_pasien` (`id_kunjungan`, `id_jadwal`, `id_tindakan`, `id_tindakan2`, `keluhan`, `jumlah`, `jumlah2`, `tagihan`, `ket_kunjungan`) VALUES (35, 59, 6, 0, 'Pemeriksaan gigi rutin', 1, 0, 300000, '');
INSERT INTO `kunjungan_pasien` (`id_kunjungan`, `id_jadwal`, `id_tindakan`, `id_tindakan2`, `keluhan`, `jumlah`, `jumlah2`, `tagihan`, `ket_kunjungan`) VALUES (36, 61, 13, 0, 'Pemeriksaan gigi rutin', 1, 0, 250000, '');
INSERT INTO `kunjungan_pasien` (`id_kunjungan`, `id_jadwal`, `id_tindakan`, `id_tindakan2`, `keluhan`, `jumlah`, `jumlah2`, `tagihan`, `ket_kunjungan`) VALUES (37, 62, 2, 0, 'Gigi sakit', 2, 0, 200000, '');
INSERT INTO `kunjungan_pasien` (`id_kunjungan`, `id_jadwal`, `id_tindakan`, `id_tindakan2`, `keluhan`, `jumlah`, `jumlah2`, `tagihan`, `ket_kunjungan`) VALUES (38, 60, 7, 6, 'Pemeriksaan gigi rutin', 1, 1, 450000, '');


#
# TABLE STRUCTURE FOR: pesan
#

DROP TABLE IF EXISTS `pesan`;

CREATE TABLE `pesan` (
  `id_pesan` int(11) NOT NULL AUTO_INCREMENT,
  `pengirim` varchar(255) NOT NULL,
  `penerima` varchar(255) NOT NULL,
  `isi_pesan` varchar(255) NOT NULL,
  `status` int(1) NOT NULL,
  `tgl_kirim` datetime NOT NULL,
  PRIMARY KEY (`id_pesan`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `pesan` (`id_pesan`, `pengirim`, `penerima`, `isi_pesan`, `status`, `tgl_kirim`) VALUES (1, 'Resepsionis', 'dokter', ' ', 0, '2023-02-21 12:06:03');


#
# TABLE STRUCTURE FOR: tanggal_pasien
#

DROP TABLE IF EXISTS `tanggal_pasien`;

CREATE TABLE `tanggal_pasien` (
  `id_tanggal` int(11) NOT NULL AUTO_INCREMENT,
  `tanggal` date NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1,
  `ket_tanggal` varchar(255) NOT NULL,
  PRIMARY KEY (`id_tanggal`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (1, '2023-02-01', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (2, '2023-02-02', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (3, '2023-02-03', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (4, '2023-02-04', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (5, '2023-02-06', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (6, '2023-02-07', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (7, '2023-02-08', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (8, '2023-02-09', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (9, '2023-02-10', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (10, '2023-02-11', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (11, '2023-02-13', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (12, '2023-02-14', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (13, '2023-02-15', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (14, '2023-02-16', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (15, '2023-02-17', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (16, '2023-02-18', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (17, '2023-02-20', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (18, '2023-02-21', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (19, '2023-02-22', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (20, '2023-02-23', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (21, '2023-02-24', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (22, '2023-02-25', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (23, '2023-02-27', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (24, '2023-02-28', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (25, '2023-03-01', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (26, '2023-03-02', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (27, '2023-03-03', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (28, '2023-03-04', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (29, '2023-03-06', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (30, '2023-03-07', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (31, '2023-03-08', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (32, '2023-03-09', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (33, '2023-03-10', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (34, '2023-03-11', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (35, '2023-03-13', 1, '');
INSERT INTO `tanggal_pasien` (`id_tanggal`, `tanggal`, `status`, `ket_tanggal`) VALUES (36, '2023-03-14', 1, '');


#
# TABLE STRUCTURE FOR: tindakan
#

DROP TABLE IF EXISTS `tindakan`;

CREATE TABLE `tindakan` (
  `id_tindakan` int(11) NOT NULL AUTO_INCREMENT,
  `nama_tindakan` varchar(255) NOT NULL,
  `harga` int(10) NOT NULL,
  `ket_tindakan` varchar(255) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_tindakan`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tindakan` (`id_tindakan`, `nama_tindakan`, `harga`, `ket_tindakan`, `status`) VALUES (1, 'Penambalan Gigi berlubang', 100000, 'gigi', 1);
INSERT INTO `tindakan` (`id_tindakan`, `nama_tindakan`, `harga`, `ket_tindakan`, `status`) VALUES (2, 'Pencabutan Gigi', 100000, 'gigi', 1);
INSERT INTO `tindakan` (`id_tindakan`, `nama_tindakan`, `harga`, `ket_tindakan`, `status`) VALUES (4, 'Pemasangan Gigi Palsu', 200000, 'gigi', 1);
INSERT INTO `tindakan` (`id_tindakan`, `nama_tindakan`, `harga`, `ket_tindakan`, `status`) VALUES (5, 'Membersihkan karang gigi', 450000, 'set', 1);
INSERT INTO `tindakan` (`id_tindakan`, `nama_tindakan`, `harga`, `ket_tindakan`, `status`) VALUES (6, 'Perawatan untuk memutihkan gigi', 300000, 'set', 1);
INSERT INTO `tindakan` (`id_tindakan`, `nama_tindakan`, `harga`, `ket_tindakan`, `status`) VALUES (7, 'Perawatan saluran akar gigi', 150000, 'gigi', 1);
INSERT INTO `tindakan` (`id_tindakan`, `nama_tindakan`, `harga`, `ket_tindakan`, `status`) VALUES (8, 'Pemasangan behel', 250000, 'set', 1);
INSERT INTO `tindakan` (`id_tindakan`, `nama_tindakan`, `harga`, `ket_tindakan`, `status`) VALUES (9, 'Perawatan Gigi Palsu', 100000, 'gigi', 1);
INSERT INTO `tindakan` (`id_tindakan`, `nama_tindakan`, `harga`, `ket_tindakan`, `status`) VALUES (10, 'Pembersihan atau Scaling gigi', 350000, 'set', 1);
INSERT INTO `tindakan` (`id_tindakan`, `nama_tindakan`, `harga`, `ket_tindakan`, `status`) VALUES (11, 'Pemasangan implan gigi', 200000, 'gigi', 1);
INSERT INTO `tindakan` (`id_tindakan`, `nama_tindakan`, `harga`, `ket_tindakan`, `status`) VALUES (12, 'Pemutihan Gigi', 150000, 'gigi', 1);
INSERT INTO `tindakan` (`id_tindakan`, `nama_tindakan`, `harga`, `ket_tindakan`, `status`) VALUES (13, 'Perawatan behel gigi', 250000, 'set', 1);


#
# TABLE STRUCTURE FOR: tindakan2
#

DROP TABLE IF EXISTS `tindakan2`;

CREATE TABLE `tindakan2` (
  `id_tindakan2` int(11) NOT NULL AUTO_INCREMENT,
  `nama_tindakan2` varchar(255) NOT NULL,
  `harga2` int(10) NOT NULL,
  `ket_tindakan2` varchar(255) NOT NULL,
  `status2` int(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_tindakan2`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tindakan2` (`id_tindakan2`, `nama_tindakan2`, `harga2`, `ket_tindakan2`, `status2`) VALUES (1, 'Penambalan Gigi berlubang', 100000, 'gigi', 1);
INSERT INTO `tindakan2` (`id_tindakan2`, `nama_tindakan2`, `harga2`, `ket_tindakan2`, `status2`) VALUES (2, 'Pencabutan Gigi', 100000, 'gigi', 1);
INSERT INTO `tindakan2` (`id_tindakan2`, `nama_tindakan2`, `harga2`, `ket_tindakan2`, `status2`) VALUES (4, 'Pemasangan Gigi Palsu', 200000, 'gigi', 1);
INSERT INTO `tindakan2` (`id_tindakan2`, `nama_tindakan2`, `harga2`, `ket_tindakan2`, `status2`) VALUES (5, 'Membersihkan karang gigi', 450000, 'set', 1);
INSERT INTO `tindakan2` (`id_tindakan2`, `nama_tindakan2`, `harga2`, `ket_tindakan2`, `status2`) VALUES (6, 'Perawatan untuk memutihkan gigi', 300000, 'set', 1);
INSERT INTO `tindakan2` (`id_tindakan2`, `nama_tindakan2`, `harga2`, `ket_tindakan2`, `status2`) VALUES (7, 'Perawatan saluran akar gigi', 150000, 'gigi', 1);
INSERT INTO `tindakan2` (`id_tindakan2`, `nama_tindakan2`, `harga2`, `ket_tindakan2`, `status2`) VALUES (8, 'Pemasangan behel', 250000, 'set', 1);
INSERT INTO `tindakan2` (`id_tindakan2`, `nama_tindakan2`, `harga2`, `ket_tindakan2`, `status2`) VALUES (9, 'Perawatan Gigi Palsu', 100000, 'gigi', 1);
INSERT INTO `tindakan2` (`id_tindakan2`, `nama_tindakan2`, `harga2`, `ket_tindakan2`, `status2`) VALUES (10, 'Pembersihan atau Scaling gigi', 350000, 'set', 1);
INSERT INTO `tindakan2` (`id_tindakan2`, `nama_tindakan2`, `harga2`, `ket_tindakan2`, `status2`) VALUES (11, 'Pemasangan implan gigi', 200000, 'gigi', 1);
INSERT INTO `tindakan2` (`id_tindakan2`, `nama_tindakan2`, `harga2`, `ket_tindakan2`, `status2`) VALUES (12, 'Pemutihan Gigi', 150000, 'gigi', 1);
INSERT INTO `tindakan2` (`id_tindakan2`, `nama_tindakan2`, `harga2`, `ket_tindakan2`, `status2`) VALUES (13, 'Perawatan behel gigi', 250000, 'set', 1);


#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(8) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `level` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `user` (`id`, `username`, `fullname`, `password`, `email`, `alamat`, `no_hp`, `level`) VALUES (1, 'admin', 'Nadia Kamila', '$2y$10$1/jK4CCVXdzksyoJBmvBiuRY0847UD0lT123YEPj3cH3ARpoQXVqC', 'admin@gmail.com', 'jalan. inaja dulu dah', '0816591527', 'Resepsionis');
INSERT INTO `user` (`id`, `username`, `fullname`, `password`, `email`, `alamat`, `no_hp`, `level`) VALUES (2, 'dokter', 'Drg. Bilal Zaidan', '$2y$10$llceyEg5X5nBu9dWHJ3WIeS01qB1soCnmyOxFv0ZfVJjMjtuRfufG', 'bilal@gmail.com', 'Badean, Bondowoso', '0816591527', 'Dokter');


